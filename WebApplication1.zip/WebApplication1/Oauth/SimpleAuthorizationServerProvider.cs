﻿//using Microsoft.Owin.Security.OAuth;
//using System.Security.Claims;
//using System.Threading.Tasks;

//namespace WebApplication1.Oauth
//{
//    //public class SimpleAuthorizationServerProvider : IOAuthAuthorizationServerProvider
//    //{
//        //public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
//        //{
//        //    context.Validated();
//        //}

//        //public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
//        //{
//        //    context.OwinContext.Response.Headers.Add("Access-Control-Allow-Origin", new[] { "*" });
//        //    // Authenfier l'utilisateur ici
//        //    if (context.UserName == "test" && context.Password == "password")
//        //    {
//        //        var identity = new ClaimsIdentity(context.Options.AuthenticationType);
//        //        identity.AddClaim(new Claim(ClaimTypes.Role, "user"));
//        //        identity.AddClaim(new Claim("username", context.UserName));
//        //        context.Validated(identity);
//        //    }
//        //    else
//        //    {
//        //        context.SetError("Invalide", "Le nom d'utisateur ou le mot de passe est incorrecte");
//        //    }
//        //}

//        public Task MatchEndpoint(OAuthMatchEndpointContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task ValidateClientRedirectUri(OAuthValidateClientRedirectUriContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task ValidateAuthorizeRequest(OAuthValidateAuthorizeRequestContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task ValidateTokenRequest(OAuthValidateTokenRequestContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task GrantAuthorizationCode(OAuthGrantAuthorizationCodeContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task GrantRefreshToken(OAuthGrantRefreshTokenContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task GrantClientCredentials(OAuthGrantClientCredentialsContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task GrantCustomExtension(OAuthGrantCustomExtensionContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task AuthorizeEndpoint(OAuthAuthorizeEndpointContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task TokenEndpoint(OAuthTokenEndpointContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task AuthorizationEndpointResponse(OAuthAuthorizationEndpointResponseContext context)
//        {
//            throw new System.NotImplementedException();
//        }

//        public Task TokenEndpointResponse(OAuthTokenEndpointResponseContext context)
//        {
//            throw new System.NotImplementedException();
//        }
//    }
//}